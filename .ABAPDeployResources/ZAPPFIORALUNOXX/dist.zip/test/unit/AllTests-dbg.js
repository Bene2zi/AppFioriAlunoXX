sap.ui.define([
	"AppFioriAlunoXX/appfiorialunoxx/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
